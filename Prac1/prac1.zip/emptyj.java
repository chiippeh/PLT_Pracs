// nearly empty program 
// K. Bradshaw July 2021

import library.*;

class emptyj {
  
  static public void main(String[] args) {
   } // main
  
} // emptyj