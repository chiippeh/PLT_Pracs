FOR 2024 -- create a new java version of Parva executable that does not have the % and += etc operators
Don't provide the Parva.exe (i.e. old C# executables) at all -- they must get used to running parva
as the class file from the first prac.

